---
name: Kinetic Lab
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display-result:
    fontFamily: JetBrains Mono
    fontSize: 48px
    fontWeight: '600'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-expression:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  key-label:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  key-operator:
    fontFamily: JetBrains Mono
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 24px
  key-modifier:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  keypad-gap: 0.75rem
  display-padding: 2rem
  container-margin: 1.5rem
  touch-target-min: 48px
---

## Brand & Style

The design system is engineered for high-stakes precision and mathematical clarity. The target audience includes engineers, data scientists, and researchers who require an environment free of visual noise. The aesthetic follows a **Technical & Precise** model, blending elements of high-end lab equipment interfaces with modern developer tools.

The interface prioritizes focus through a dark, low-glare environment. It avoids decorative elements, instead finding beauty in functional geometry, rigid alignment, and high-readability data displays. The emotional response is one of reliability, computational power, and professional-grade utility.

## Colors

This design system utilizes a "Deep Field" palette to minimize eye strain during extended use. 

- **Primary (Action Blue):** Used for the "Enter" or "Execute" commands.
- **Secondary (Success Green):** Used for result indicators or active state toggles.
- **Tertiary (Function Amber):** Reserved for advanced scientific modifiers (Shift, Alpha, 2nd).
- **Neutral (Slate Hierarchy):** A range of cool grays used to differentiate the housing (Canvas), the read-out (Display), and the input area (Keypad).

The palette ensures high contrast for mathematical glyphs while maintaining a low overall luminance to prevent screen glare in dim laboratory or office settings.

## Typography

Typography is the core of the computational experience. We use **JetBrains Mono** for all mathematical expressions, variables, and results to ensure that every character (especially `0` and `O`, or `1` and `l`) is distinct. 

**Geist** is used for secondary UI labels and interface controls where a clean, high-legibility sans-serif is required to balance the technical nature of the monospaced numerals. 

The "Display" area uses a multi-line hierarchy: the current expression is rendered in a medium-weight monospace, while the result is displayed in a larger, high-contrast bold weight to provide immediate visual confirmation.

## Layout & Spacing

The layout is divided into two distinct zones: the **Observation Zone** (Display) and the **Interaction Zone** (Keypad).

- **Observation Zone:** Occupies the top 35-40% of the interface. It uses generous internal padding to ensure the numbers do not crowd the edges of the frame.
- **Interaction Zone:** Utilizes a rigid grid. On desktop, this is a fixed-width module to maintain muscle memory. On mobile, it stretches to fill the width (fluid grid) but maintains fixed aspect ratios for keys to ensure they remain easily tappable.

A consistent 12px (0.75rem) gap is maintained between all calculator keys to prevent accidental inputs.

## Elevation & Depth

This design system avoids traditional shadows in favor of **Tonal Layering** and **Subtle Inner Glows**. 

1. **The Canvas:** The lowest layer, using the darkest neutral shade.
2. **The Display Well:** Recessed slightly using a subtle inner shadow or a darker border-top to simulate depth.
3. **The Keys:** Use a "Flat-Tactile" approach. Keys do not have drop shadows; instead, they use a 1px solid bottom border (20% lighter than the key surface) to provide a sense of physical thickness. When pressed, the key shifts down 1px and the border disappears, providing immediate haptic and visual feedback.

## Shapes

The shape language is "Soft-Industrial." We use a base roundedness of 4px (`0.25rem`) for keys to maintain a precise, technical look without the harshness of sharp 90-degree corners. 

The main display area and outer container may use `rounded-lg` (8px) to soften the overall silhouette of the device, while internal components like input fields and individual buttons remain strictly `rounded-sm`.

## Components

### Calculator Keys
- **Numeric Keys:** Surface color `slate-800`, text `white`. The workhorse of the UI.
- **Operator Keys (+, -, ×, ÷):** Surface color `slate-700`, text `primary`. Slightly higher contrast than numeric keys.
- **Scientific Functions (sin, log, √):** Surface color `slate-900`, text `slate-300`, font size `label-sm`.
- **Primary Action (Enter/Equal):** Surface color `primary`, text `white`. Boldest element.
- **Clear/Delete:** Surface color `slate-900`, text `accent_critical`. 

### The Display Area
The display is a multi-line "tape" style.
- **Expression Line:** Top-aligned, muted text, shows the full calculation string including parentheses.
- **Result Line:** Bottom-aligned, primary text color, maximum font size.

### Mode Toggles
Small, pill-shaped chips at the top of the display (e.g., DEG/RAD, SCI/FIX) that use a subtle glow effect when active to indicate the current state of the calculation engine.